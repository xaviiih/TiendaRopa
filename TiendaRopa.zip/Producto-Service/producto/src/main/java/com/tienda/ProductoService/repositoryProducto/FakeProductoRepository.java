package com.tienda.ProductoService.repositoryProducto;

import com.tienda.ProductoService.modelProducto.Producto;
import java.util.*;

/**
 * Repositorio en memoria usado SOLO en pruebas unitarias (no es un bean de
 * Spring, no requiere Oracle). Se instancia manualmente con "new" desde los
 * tests, junto a ProductoServiceProbar.
 */
public class FakeProductoRepository {
    private final Map<Long, Producto> datos = new HashMap<>();

    public FakeProductoRepository() {
        datos.put(1L, crear(1L, "Polera basica", 9990, 50));
        datos.put(2L, crear(2L, "Jeans slim", 24990, 20));
        datos.put(3L, crear(3L, "Chaqueta impermeable", 39990, 5));
    }

    private Producto crear(Long id, String nombre, double precio, int stock) {
        Producto p = new Producto();
        p.setId(id);
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setStock(stock);
        return p;
    }

    public Optional<Producto> findById(Long id) { return Optional.ofNullable(datos.get(id)); }
    public List<Producto> findAll() { return new ArrayList<>(datos.values()); }
    public Producto save(Producto producto) { datos.put(producto.getId(), producto); return producto; }
    public void deleteById(Long id) { datos.remove(id); }
}
