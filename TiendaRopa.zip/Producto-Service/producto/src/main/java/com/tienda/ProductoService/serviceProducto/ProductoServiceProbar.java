package com.tienda.ProductoService.serviceProducto;

import com.tienda.ProductoService.modelProducto.Producto;
import com.tienda.ProductoService.repositoryProducto.FakeProductoRepository;
import java.util.List;

/**
 * Variante de ProductoService usada solo en pruebas unitarias con
 * FakeProductoRepository. No lleva @Service a proposito: si lo tuviera,
 * Spring intentaria crearla como bean real al levantar el contexto.
 */
public class ProductoServiceProbar {
    private final FakeProductoRepository repo;

    public ProductoServiceProbar(FakeProductoRepository repo) {
        this.repo = repo;
    }

    public List<Producto> listar() { return repo.findAll(); }

    public Producto guardar(Producto producto) {
        if (producto.getPrecio() < 1) {
            throw new IllegalArgumentException("El precio no puede ser menor a 1");
        }
        return repo.save(producto);
    }

    public Producto obtener(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void eliminar(Long id) { repo.deleteById(id); }
}
