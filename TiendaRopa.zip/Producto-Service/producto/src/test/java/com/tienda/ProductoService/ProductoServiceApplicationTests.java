package com.tienda.ProductoService;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexion a Oracle. La logica de negocio se prueba en ProductoTest con un repositorio falso.")
class ProductoServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
