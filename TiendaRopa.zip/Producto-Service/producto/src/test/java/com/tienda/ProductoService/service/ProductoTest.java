package com.tienda.ProductoService.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.ProductoService.repositoryProducto.FakeProductoRepository;
import com.tienda.ProductoService.serviceProducto.ProductoServiceProbar;
import com.tienda.ProductoService.modelProducto.Producto;

/**
 * Pruebas unitarias del Service de Producto usando un repositorio falso
 * (FakeProductoRepository). No depende de Spring ni de Oracle.
 */
public class ProductoTest {

    @Test
    void debeRetornarProductoCuandoExiste() {
        ProductoServiceProbar service = new ProductoServiceProbar(new FakeProductoRepository());

        Producto producto = service.obtener(1L);

        assertNotNull(producto);
        assertEquals("Polera basica", producto.getNombre());
    }

    @Test
    void debeRetornarNullCuandoProductoNoExiste() {
        ProductoServiceProbar service = new ProductoServiceProbar(new FakeProductoRepository());

        assertNull(service.obtener(99L));
    }

    @Test
    void debeListarLosTresProductosPrecargados() {
        ProductoServiceProbar service = new ProductoServiceProbar(new FakeProductoRepository());

        assertEquals(3, service.listar().size());
    }

    @Test
    void debeRechazarProductoConPrecioInvalido() {
        ProductoServiceProbar service = new ProductoServiceProbar(new FakeProductoRepository());
        Producto invalido = new Producto();
        invalido.setId(4L);
        invalido.setNombre("Producto gratis");
        invalido.setPrecio(0);
        invalido.setStock(1);

        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalido));
    }
}
