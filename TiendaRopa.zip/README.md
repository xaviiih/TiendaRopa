# TiendaTodo

## Integrantes

* <Xavier Ojeda>
* <Arlete Patiño>

## Repositorio GitHub

🔗 https://github.com/xaviiih/TiendaRopa

## Descripción

TiendaTodo es un sistema de gestión para una tienda de ropa desarrollado mediante arquitectura de microservicios con Spring Boot. El sistema permite administrar clientes, productos, vendedores, proveedores, carritos de compra, ventas, envíos, pagos, sucursales y valoraciones. Incorpora comunicación entre microservicios mediante OpenFeign + Eureka (service discovery), documentación con Swagger/OpenAPI, pruebas unitarias y despliegue mediante Docker Compose.

## Arquitectura

```
                        ┌─────────────────┐
                        │  Eureka Server   │  :8761
                        │ (service registry)│
                        └────────▲─────────┘
                                 │ registro
        ┌────────────────────────┼───────────────────────────┐
        │                        │                            │
┌───────┴──────┐        ┌────────┴────────┐          ┌────────┴────────┐
│  API Gateway  │ :8080  │ carrito-service │ :8081     │ cliente-service │ :1082
│ (Spring Cloud │───────▶│ envio-service   │ :8082     │ producto-service│ :1084 ──▶ proveedor-service :1086 (Feign)
│   Gateway)    │        │ venta-service   │ :8083     │ vendedor-service│ :1085
└───────────────┘        └─────────────────┘          │ valoracion-svc  │ :1087
                                                        │ sucursal-svc    │ :1088
                                                        │ pago-service    │ :1089
                                                        └─────────────────┘
```

Todos los microservicios se registran en Eureka y el API Gateway enruta las peticiones externas usando balanceo de carga (`lb://nombre-servicio`) en vez de URLs fijas.

## Microservicios, puertos y rutas

| Microservicio | Puerto directo | Ruta vía Gateway (`localhost:8080`) | Base de datos (alias TNS) |
|---|---|---|---|
| eureka-server | 8761 | — (panel: `/`) | — |
| api-gateway | 8080 | — | — |
| carrito-service | 8081 | `/API/V1/carritos/**` | fullstack_high |
| envio-service | 8082 | `/API/V1/envios/**` | fullstack_high |
| venta-service | 8083 | `/API/V1/ventas/**` | fullstack_high |
| cliente-service | 1082 | `/API/V1/clientes/**` | bd2_high |
| producto-service | 1084 | `/API/V1/productos/**` | bd2_high |
| vendedor-service | 1085 | `/API/V1/vendedores/**` | bd2_medium |
| proveedor-service | 1086 | `/API/V1/proveedores/**` | bd2_low |
| valoracion-service | 1087 | `/API/V1/valoraciones/**` | bd2_low |
| sucursal-service | 1088 | `/API/V1/sucursales/**` | bd2_low |
| pago-service | 1089 | `/API/V1/pagos/**` | bd2_low |

### Comunicación entre microservicios (Feign)

* `venta-service` → `carrito-service`
* `envio-service` → `venta-service`
* `producto-service` → `proveedor-service`

## Cómo ejecutar el proyecto (Docker Compose)

### 1. Requisitos previos

* Docker y Docker Compose instalados.
* Un Wallet de Oracle Autonomous DB descomprimido en tu computador (el mismo wallet sirve para todos los servicios; solo cambia el alias de servicio usado en cada `jdbc:oracle:thin:@<alias>`).

### 2. Configurar variables de entorno

Crea un archivo `.env` en esta misma carpeta (junto a `docker-compose.yml`), usando `.env.example` como base:

```
ORACLE_WALLET_PATH=D:/OracleWallet
ORACLE_DB_USERNAME=ADMIN
ORACLE_DB_PASSWORD=tu_password_aqui
```
### 3. Levantar todo

```bash
docker compose up --build
```

Esto construye y levanta, en orden: `eureka-server` → los 9 microservicios → `api-gateway`.

### 4. Verificar que todo se registró en Eureka

Abre http://localhost:8761. Deberías ver las 10 aplicaciones (`API-GATEWAY`, `CARRITO-SERVICE`, `ENVIO-SERVICE`, `VENTA-SERVICE`, `CLIENTE-SERVICE`, `PRODUCTO-SERVICE`, `VENDEDOR-SERVICE`, `PROVEEDOR-SERVICE`, `VALORACION-SERVICE`, `SUCURSAL-SERVICE`, `PAGO-SERVICE`) en estado **UP**. Toma una captura de esta pantalla como evidencia.

### 5. Cargar datos de prueba

Las tablas se crean solas la primera vez que cada servicio arranca (`spring.jpa.hibernate.ddl-auto=update`). Para tener datos con los que probar, ejecuta el script [`datos_prueba.sql`](./datos_prueba.sql) contra tu base Oracle (instrucciones dentro del archivo, ya que cada servicio usa un alias distinto del mismo wallet).

### 6. Detener los contenedores

```bash
docker compose down
```

## Documentación de la API (Swagger / OpenAPI)

Cada microservicio expone su propio Swagger UI en `http://localhost:<puerto>/swagger-ui.html` (o `/swagger-ui/index.html` según versión), por ejemplo:

* Carrito: http://localhost:8081/swagger-ui.html
* Producto: http://localhost:1084/swagger-ui.html
* Cliente: http://localhost:1082/swagger-ui.html
* Proveedor: http://localhost:1086/swagger-ui.html
* Vendedor: http://localhost:1085/swagger-ui.html
* Sucursal: http://localhost:1088/swagger-ui.html
* Valoración: http://localhost:1087/swagger-ui.html
* Pago: http://localhost:1089/swagger-ui.html

El JSON de OpenAPI está en `/v3/api-docs` de cada servicio.

## Endpoints principales (vía API Gateway, puerto 8080)

* Carritos: http://localhost:8080/API/V1/carritos
* Envíos: http://localhost:8080/API/V1/envios
* Ventas: http://localhost:8080/API/V1/ventas
* Clientes: http://localhost:8080/API/V1/clientes
* Productos: http://localhost:8080/API/V1/productos
* Vendedores: http://localhost:8080/API/V1/vendedores
* Proveedores: http://localhost:8080/API/V1/proveedores
* Valoraciones: http://localhost:8080/API/V1/valoraciones
* Sucursales: http://localhost:8080/API/V1/sucursales
* Pagos: http://localhost:8080/API/V1/pagos

## Cómo ejecutar pruebas unitarias

Por microservicio:

```powershell
cd carrito-service\carrito
.\mvnw.cmd test
```

Repite lo mismo cambiando la carpeta por: `envio-service\envio`, `venta-service\venta`, `cliente-service\cliente`, `Producto-Service\producto`, `proveedor-serivce\proveedor`, `vendedor-service\vendedor`, `sucursal-service\sucursal`, `valoracion-service\valoracion`, `pago-service\pago`.

Todos los microservicios siguen el mismo patrón de pruebas: el `*ApplicationTests` autogenerado por Spring Initializr está marcado con `@Disabled` (requiere Oracle real), y la lógica de negocio se prueba de forma aislada con un repositorio falso en memoria (`FakeXxxRepository` + `XxxServiceProbar`, sin Spring ni base de datos):

| Servicio | Clase de test | Qué cubre |
|---|---|---|
| carrito-service | `CarritoTest` | find por id, listar, error si no existe |
| envio-service | `EnvioTest` | lógica de envíos |
| venta-service | `VentaTest` | lógica de ventas |
| cliente-service | `ClienteTest` | find, listar, validación de email |
| producto-service | `ProductoTest` | find, listar, validación de precio |
| proveedor-service | `ProveedorTest` | find, listar, validación de empresa |
| vendedor-service | `VendedorTest` | find, listar, validación de teléfono |
| sucursal-service | `SucursalTest` | find, listar, validación de comuna |
| valoracion-service | `ValoracionTest` | find, listar, validación de rango de estrellas |
| pago-service | `PagoTest` | find, listar, validación de método de pago |

Resultado esperado por servicio: `BUILD SUCCESS` con los tests de `*Test.java` en verde y el `*ApplicationTests` como `SKIPPED` (por el `@Disabled`).

## Script de base de datos / datos de prueba

No se necesita un script de creación de tablas: Hibernate las genera automáticamente (`ddl-auto=update`) al levantar cada servicio contra Oracle. Lo que sí se entrega es [`datos_prueba.sql`](./datos_prueba.sql), con `INSERT` de ejemplo para las 10 tablas, pensado para poder probar los endpoints GET y las llamadas Feign entre servicios sin partir de una base vacía.

## Usuarios / credenciales de prueba

Este proyecto **no implementa autenticación de usuarios finales** (no hay login ni Spring Security) — todos los endpoints son abiertos vía el Gateway. Lo que sí necesita quien revise el proyecto:

* **Credenciales de la base Oracle**: usuario `ADMIN` y la contraseña que se defina en `.env` (`ORACLE_DB_PASSWORD`). No se comparten contraseñas reales en este README ni en el repositorio; se entregan aparte al equipo docente/revisor.
* **Wallet de Oracle**: se debe solicitar aparte (no va en Git), y su ruta local se indica en `ORACLE_WALLET_PATH`.
* **IDs de prueba** ya cargados por `datos_prueba.sql`: cliente `1,2,3`, producto `1,2,3`, proveedor `1,2,3`, etc. (ver el script para el detalle completo).

## Evidencias

* Captura de la estructura del proyecto mostrando la carpeta src/test/java en los 3 microservicios (carrito, envio y venta).
![alt text](image.png)
* Captura de las clases de pruebas unitarias (CarritoTest, EnvioTest y VentaTest).
![alt text](image-1.png)![alt text](image-2.png)![alt text](image-3.png)
* Captura de `docker compose up --build` ejecutándose correctamente.
![alt text](image-11.png)
* Captura de Eureka Server mostrando los 4 servicios registrados como UP (api-gateway, carrito-service, envio-service, venta-service).
![alt text](image-4.png)
* Captura de pruebas GET y POST exitosas en Postman por puerto directo (carrito 8081, envio 8082, venta 8083).
![alt text](image-5.png)![alt text](image-6.png)![alt text](image-7.png)
* Captura de pruebas GET exitosas realizadas sobre los endpoints principales via API Gateway (puerto 8080).
![alt text](image-8.png)![alt text](image-9.png)![alt text](image-10.png)

* Captura de Eureka Server mostrando los 10 servicios UP, y de Postman/Swagger probando cliente, producto, proveedor, vendedor, sucursal, valoración y pago (agregar imagen aquí una vez levantado el proyecto: `![alt text](image-12.png)`).

## Problemas conocidos y soluciones

### 1. ApplicationTests fallaban al ejecutar mvn test
Los archivos `*ApplicationTests` (en los 10 microservicios) intentan levantar el contexto completo de Spring Boot, lo que requiere conexión activa a Oracle. Esto causaba `BUILD FAILURE` en entornos sin base de datos disponible.

**Solución:** se agregó la anotación `@Disabled` en las diez clases con una descripción explicando que la lógica de negocio se prueba de forma aislada en `*Test` usando un `FakeRepository`.

### 2. Swagger incompatible con Spring Boot 4
La dependencia `springdoc-openapi-starter-webmvc-ui` en versiones 2.3.0 y 2.6.0 no es compatible con Spring Boot 4.0.6, generando el error `NoSuchMethodError: ControllerAdviceBean` al intentar cargar la definición de la API.

**Solución:** se usó la versión 2.8.9 de Springdoc en los diez `pom.xml`.

### 3. POST a carrito fallaba con ORA-01400 (inserción NULL)
Al intentar crear un carrito enviando solo `id_cliente` y `estado`, Oracle rechazaba la inserción porque la tabla `CARRITO` tiene columnas `NOT NULL` adicionales: `fecha`, `id_empleado`, `id_sucursal` y `nro_cliente`.

**Solución:** se completó el body del request con todos los campos obligatorios que define la tabla en Oracle.

### 4. Los 7 microservicios nuevos no se conectaban entre sí
Al agregarlos al proyecto quedaron sin dependencia de Eureka, sin `Dockerfile`, sin entrada en `docker-compose.yml` y sin rutas en el Gateway, por lo que ni se registraban en el service discovery ni eran alcanzables desde afuera. `producto-service` además llamaba a `proveedor-service` con una URL fija (`http://localhost:8085`) en vez de usar el nombre registrado en Eureka.

**Solución:** se agregó `spring-cloud-starter-netflix-eureka-client` y su configuración a los 7 `pom.xml`/`application.properties`, se crearon los `Dockerfile` faltantes, se agregaron las 7 entradas a `docker-compose.yml` y las 7 rutas al Gateway, y se quitó la URL fija del `@FeignClient` de `producto-service` para que use balanceo de carga vía Eureka.

## URLs principales

* Eureka Server: http://localhost:8761
* API Gateway: http://localhost:8080
* carrito-service: http://localhost:8081
* envio-service: http://localhost:8082
* venta-service: http://localhost:8083
* cliente-service: http://localhost:1082
* producto-service: http://localhost:1084
* vendedor-service: http://localhost:1085
* proveedor-service: http://localhost:1086
* valoracion-service: http://localhost:1087
* sucursal-service: http://localhost:1088
* pago-service: http://localhost:1089
