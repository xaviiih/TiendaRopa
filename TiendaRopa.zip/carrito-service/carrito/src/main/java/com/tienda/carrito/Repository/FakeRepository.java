/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.carrito.Repository;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.tienda.carrito.Modelo.Carrito;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Arlettee
 */
public class FakeRepository {
    private final Map<Integer, Carrito> carrito= new HashMap<>();
    
public FakeRepository(){
    carrito.put(1,new Carrito(1,1, LocalDate.now(), 2, 3, 4, 100.0));
    carrito.put(2,new Carrito(2,1, LocalDate.now(), 3, 4, 5, 200.0));
    carrito.put(3,new Carrito(3,3, LocalDate.now(), 4, 5, 6, 600.0));
}
//GET(ID)
public Optional<Carrito> findById(int id){
    return Optional.ofNullable(carrito.get(id));
}
//GET
public List<Carrito> findAll(){
return new ArrayList<>(carrito.values());}

//POST
public Carrito save(Carrito nuevoCarrito){
    carrito.put(nuevoCarrito.getId_carrito(), nuevoCarrito);
        
     return nuevoCarrito;}

//DELETE
public void deleteById(int id){
    carrito.remove(id);
}




}
