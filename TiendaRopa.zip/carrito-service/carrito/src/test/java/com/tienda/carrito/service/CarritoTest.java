package com.tienda.carrito.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.carrito.Repository.FakeRepository;
import com.tienda.carrito.Service.CarritoServiceProbar;
import com.tienda.carrito.Modelo.Carrito;

/**
 * Pruebas unitarias del Service de Carrito usando un repositorio falso
 * (FakeRepository), siguiendo el patrón Given/When/Then de la guía.
 * No depende de Spring ni de la base de datos real: por eso no usa
 * @SpringBootTest y se ejecuta de forma aislada con "mvn test".
 */
public class CarritoTest {

    @Test
    void debeRetornarCarritoCuandoExiste() {
        // GIVEN: el FakeRepository precarga 3 carritos (ids 1, 2 y 3)
        FakeRepository fakeRepository = new FakeRepository();
        CarritoServiceProbar service = new CarritoServiceProbar(fakeRepository);

        // WHEN
        Carrito carrito = service.findById(1);

        // THEN
        assertNotNull(carrito);
        assertEquals(1, carrito.getId_carrito());
        assertEquals(100.0, carrito.getTotal());
    }

    @Test
    void debeLanzarErrorCuandoCarritoNoExiste() {
        // GIVEN
        FakeRepository fakeRepository = new FakeRepository();
        CarritoServiceProbar service = new CarritoServiceProbar(fakeRepository);

        // WHEN + THEN
        assertThrows(RuntimeException.class, () -> {
            service.findById(99);
        });
    }

    @Test
    void debeListarTodosLosCarritosPrecargados() {
        // GIVEN: FakeRepository inicializa exactamente 3 carritos
        FakeRepository fakeRepository = new FakeRepository();
        CarritoServiceProbar service = new CarritoServiceProbar(fakeRepository);

        // WHEN
        var carritos = service.findAll();

        // THEN
        assertEquals(3, carritos.size());
    }
}
