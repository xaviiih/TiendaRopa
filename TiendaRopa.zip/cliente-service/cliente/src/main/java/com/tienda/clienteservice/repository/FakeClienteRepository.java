package com.tienda.clienteservice.repository;

import com.tienda.clienteservice.model.ClienteModel;
import java.util.*;

public class FakeClienteRepository {
    private final Map<Long, ClienteModel> datos = new HashMap<>();

    public FakeClienteRepository() {
        datos.put(1L, crear(1L, "Ana Torres", "ana.torres@mail.com"));
        datos.put(2L, crear(2L, "Bruno Diaz", "bruno.diaz@mail.com"));
        datos.put(3L, crear(3L, "Carla Soto", "carla.soto@mail.com"));
    }

    private ClienteModel crear(Long id, String nombre, String email) {
        ClienteModel c = new ClienteModel();
        c.setId(id); c.setNombre(nombre); c.setEmail(email);
        return c;
    }

    public Optional<ClienteModel> findById(Long id) { return Optional.ofNullable(datos.get(id)); }
    public List<ClienteModel> findAll() { return new ArrayList<>(datos.values()); }
    public ClienteModel save(ClienteModel c) { datos.put(c.getId(), c); return c; }
    public void deleteById(Long id) { datos.remove(id); }
}
