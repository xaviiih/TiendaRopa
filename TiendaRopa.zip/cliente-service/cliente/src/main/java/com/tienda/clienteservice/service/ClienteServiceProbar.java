package com.tienda.clienteservice.service;

import com.tienda.clienteservice.model.ClienteModel;
import com.tienda.clienteservice.repository.FakeClienteRepository;
import java.util.List;

public class ClienteServiceProbar {
    private final FakeClienteRepository repo;

    public ClienteServiceProbar(FakeClienteRepository repo) { this.repo = repo; }

    public List<ClienteModel> listar() { return repo.findAll(); }

    public ClienteModel guardar(ClienteModel cliente) {
        if (cliente.getEmail() == null || !cliente.getEmail().contains("@")) {
            throw new IllegalArgumentException("Email invalido");
        }
        return repo.save(cliente);
    }

    public ClienteModel obtener(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
