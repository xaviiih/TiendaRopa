package com.tienda.clienteservice;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexion a Oracle. La logica de negocio se prueba en ClienteTest con un repositorio falso.")
class ClienteServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
