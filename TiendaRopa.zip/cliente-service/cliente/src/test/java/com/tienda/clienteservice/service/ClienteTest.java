package com.tienda.clienteservice.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.clienteservice.repository.FakeClienteRepository;
import com.tienda.clienteservice.model.ClienteModel;

public class ClienteTest {

    @Test
    void debeRetornarClienteCuandoExiste() {
        ClienteServiceProbar service = new ClienteServiceProbar(new FakeClienteRepository());
        ClienteModel cliente = service.obtener(1L);
        assertNotNull(cliente);
        assertEquals("Ana Torres", cliente.getNombre());
    }

    @Test
    void debeRetornarNullCuandoClienteNoExiste() {
        ClienteServiceProbar service = new ClienteServiceProbar(new FakeClienteRepository());
        assertNull(service.obtener(99L));
    }

    @Test
    void debeListarLosTresClientesPrecargados() {
        ClienteServiceProbar service = new ClienteServiceProbar(new FakeClienteRepository());
        assertEquals(3, service.listar().size());
    }

    @Test
    void debeRechazarEmailInvalido() {
        ClienteServiceProbar service = new ClienteServiceProbar(new FakeClienteRepository());
        ClienteModel invalido = new ClienteModel();
        invalido.setId(4L);
        invalido.setNombre("Cliente Malo");
        invalido.setEmail("no-es-un-email");
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalido));
    }
}
