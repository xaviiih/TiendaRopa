-- ============================================================
-- TiendaTodo - Datos de prueba
-- ============================================================
-- Como los microservicios usan spring.jpa.hibernate.ddl-auto=update,
-- las TABLAS se crean solas la primera vez que cada servicio arranca
-- y se conecta a Oracle. Este script solo INSERTA datos de ejemplo,
-- para poder probar los endpoints (GET, Feign entre servicios, etc.)
-- sin partir de una base vacía.
--
-- Cómo usarlo:
--   1. Levanta todo con "docker compose up --build" (o corre cada
--      servicio local con Maven) para que Hibernate cree las tablas.
--   2. Abre SQL Developer / DBeaver conectado con tu wallet de Oracle.
--   3. Ejecuta este script completo (o por bloques, servicio por servicio).
--
-- IMPORTANTE: cada microservicio tiene su PROPIA base/esquema
-- (mismo wallet, distinto alias de servicio). Conéctate al esquema
-- correspondiente antes de correr cada bloque:
--   - CARRITO, VENTA, ENVIO            -> alias fullstack_high
--   - CLIENTE, PRODUCTO                -> alias bd2_high
--   - VENDEDOR                         -> alias bd2_medium
--   - PROVEEDOR, SUCURSAL, VALORACION, PAGO -> alias bd2_low
-- ============================================================

-- ============ CLIENTE (bd2_high) ============
INSERT INTO CLIENTE (ID, NOMBRE, EMAIL) VALUES (1, 'Ana Torres', 'ana.torres@mail.com');
INSERT INTO CLIENTE (ID, NOMBRE, EMAIL) VALUES (2, 'Bruno Diaz', 'bruno.diaz@mail.com');
INSERT INTO CLIENTE (ID, NOMBRE, EMAIL) VALUES (3, 'Carla Soto', 'carla.soto@mail.com');

-- ============ PROVEEDOR (bd2_low) ============
INSERT INTO PROVEEDOR (ID, NOMBRE, EMPRESA) VALUES (1, 'Juan Perez', 'Textiles del Sur');
INSERT INTO PROVEEDOR (ID, NOMBRE, EMPRESA) VALUES (2, 'Maria Lopez', 'Confecciones Andes');
INSERT INTO PROVEEDOR (ID, NOMBRE, EMPRESA) VALUES (3, 'Pedro Ramirez', 'Importadora Pacifico');

-- ============ PRODUCTO (bd2_high) - depende de PROVEEDOR vía Feign ============
INSERT INTO PRODUCTO (ID, NOMBRE, PRECIO, STOCK) VALUES (1, 'Polera basica', 9990, 50);
INSERT INTO PRODUCTO (ID, NOMBRE, PRECIO, STOCK) VALUES (2, 'Jeans slim', 24990, 20);
INSERT INTO PRODUCTO (ID, NOMBRE, PRECIO, STOCK) VALUES (3, 'Chaqueta impermeable', 39990, 5);

-- ============ VENDEDOR (bd2_medium) ============
INSERT INTO VENDEDOR (ID, NOMBRE, TELEFONO) VALUES (1, 'Diego Fuentes', '+56911111111');
INSERT INTO VENDEDOR (ID, NOMBRE, TELEFONO) VALUES (2, 'Elena Vidal', '+56922222222');
INSERT INTO VENDEDOR (ID, NOMBRE, TELEFONO) VALUES (3, 'Felipe Rojas', '+56933333333');

-- ============ SUCURSAL (bd2_low) ============
INSERT INTO SUCURSAL (ID_SUCURSAL, COMUNA) VALUES (1, 'Providencia');
INSERT INTO SUCURSAL (ID_SUCURSAL, COMUNA) VALUES (2, 'Las Condes');
INSERT INTO SUCURSAL (ID_SUCURSAL, COMUNA) VALUES (3, 'Nunoa');

-- ============ CARRITO (fullstack_high) ============
INSERT INTO CARRITO (ID_CARRITO, ID_SUCURSAL, FECHA, ID_EMPLEADO, NRO_CLIENTE, CANT_PRODUCTOS, TOTAL)
  VALUES (1, 1, SYSDATE, 1, 1, 2, 34980);
INSERT INTO CARRITO (ID_CARRITO, ID_SUCURSAL, FECHA, ID_EMPLEADO, NRO_CLIENTE, CANT_PRODUCTOS, TOTAL)
  VALUES (2, 2, SYSDATE, 2, 2, 1, 24990);
INSERT INTO CARRITO (ID_CARRITO, ID_SUCURSAL, FECHA, ID_EMPLEADO, NRO_CLIENTE, CANT_PRODUCTOS, TOTAL)
  VALUES (3, 3, SYSDATE, 3, 3, 3, 74970);

-- ============ VENTA (fullstack_high) - depende de CARRITO vía Feign ============
INSERT INTO VENTA (ID, FECHA, TOTAL, ESTADO) VALUES (1, SYSDATE, 34980, 1);
INSERT INTO VENTA (ID, FECHA, TOTAL, ESTADO) VALUES (2, SYSDATE, 24990, 1);
INSERT INTO VENTA (ID, FECHA, TOTAL, ESTADO) VALUES (3, SYSDATE, 74970, 0);

-- ============ ENVIO (fullstack_high) - depende de VENTA vía Feign ============
INSERT INTO ENVIO (ID_ENVIO, DIRECCION, ESTADO, ID_VENTA) VALUES (1, 'Av. Providencia 1234', 'ENTREGADO', 1);
INSERT INTO ENVIO (ID_ENVIO, DIRECCION, ESTADO, ID_VENTA) VALUES (2, 'Av. Apoquindo 4321', 'EN_CAMINO', 2);
INSERT INTO ENVIO (ID_ENVIO, DIRECCION, ESTADO, ID_VENTA) VALUES (3, 'Irarrazaval 555', 'PENDIENTE', 3);

-- ============ PAGO (bd2_low) ============
INSERT INTO PAGO (ID_PAGO, METODO_PAGO, NRO_CLIENTE, ID_PEDIDO) VALUES (1, 'Tarjeta de credito', 1, 10);
INSERT INTO PAGO (ID_PAGO, METODO_PAGO, NRO_CLIENTE, ID_PEDIDO) VALUES (2, 'Transferencia', 2, 11);
INSERT INTO PAGO (ID_PAGO, METODO_PAGO, NRO_CLIENTE, ID_PEDIDO) VALUES (3, 'Webpay', 3, 12);

-- ============ VALORACION (bd2_low) ============
INSERT INTO VALORACION (ID_VALORACION, ID_PRODUCTO, NRO_CLIENTE, ESTRELLAS, FECHA_PUBLICACION) VALUES (1, 1, 1, 5, SYSDATE);
INSERT INTO VALORACION (ID_VALORACION, ID_PRODUCTO, NRO_CLIENTE, ESTRELLAS, FECHA_PUBLICACION) VALUES (2, 2, 2, 4, SYSDATE);
INSERT INTO VALORACION (ID_VALORACION, ID_PRODUCTO, NRO_CLIENTE, ESTRELLAS, FECHA_PUBLICACION) VALUES (3, 1, 3, 3, SYSDATE);

COMMIT;
