package com.tienda.envio.Modelo;
import jakarta.persistence.*;

@Entity
@Table(name="Envio")

public class Envio{
    @Id
    @Column(nullable=false)
    private int id_envio;
    @Column(nullable=false)
    private String direccion;
    @Column(nullable=false)
    private String estado;
    @Column(nullable=false)
    private int id_venta;
    public Envio(){}
    public Envio(int id_envio, String direccion, String estado, int id_venta){
        this.id_envio=id_envio;
        this.direccion=direccion;
        this.estado=estado;
        this.id_venta=id_venta;
        
    }

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }

    public int getId_envio(){
        return id_envio;
    }
    
    public String getDireccion(){
        return direccion;
    }
    public String getEstado(){
        return estado;
    }

    public void setId_envio(int id_envio){
        this.id_envio=id_envio;
    }
    
    public void setDireccion(String direccion){
        this.direccion=direccion;
    }
    public void setEstado(String estado){
        this.estado=estado;
    }

}
