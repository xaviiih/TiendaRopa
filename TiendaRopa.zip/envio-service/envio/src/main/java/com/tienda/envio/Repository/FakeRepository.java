/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.envio.Repository;
import com.tienda.envio.Modelo.Envio;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;



/**
 *
 * @author Arlettee
 */
public class FakeRepository {
    private final Map<Integer, Envio> envios= new HashMap<>();
    
public FakeRepository(){
    envios.put(1,new Envio(1,"direccion1", "En curso",1));
    envios.put(2,new Envio(2, "direccion2", "Completado",2));
    envios.put(3,new Envio(3, "direccion3", "En curso",99));
}
//GET{ID}
public Optional<Envio> findById(int id){
    return Optional.ofNullable(envios.get(id));
}
//GET
public List<Envio> findAll(){
return new ArrayList<>(envios.values());}

//POST
public Envio save(Envio nuevoEnvio){
    envios.put(nuevoEnvio.getId_envio(), nuevoEnvio);
        
     return nuevoEnvio;}

//DELETE
public void deleteById(int id){
    envios.remove(id);

}

    
}
