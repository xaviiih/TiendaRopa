package com.tienda.envio.Service;

import com.tienda.envio.Client.VentaClient;
import com.tienda.envio.dto.VentaResponseDTO;
import com.tienda.envio.Modelo.Envio;
import com.tienda.envio.Repository.EnvioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class EnvioService {

    private static final Logger logger = LoggerFactory.getLogger(EnvioService.class);

    private final VentaClient ventaClient;
    private final EnvioRepository envioRepository;

    public EnvioService(VentaClient ventaClient, EnvioRepository envioRepository) {
        this.ventaClient = ventaClient;
        this.envioRepository = envioRepository;
    }

    public List<Envio> findAll() {
        logger.info("Obteniendo todos los envios");
        return envioRepository.findAll();
    }

    public Envio findById(int id) {
        logger.info("Buscando envio con id: {}", id);
        return envioRepository.findById(id).orElse(null);
    }

    public Envio save(Envio nuevoEnvio) {
        logger.info("Creando envio para venta id: {}", nuevoEnvio.getId_venta());
        
        VentaResponseDTO venta;
        //consultar venta
        try {
            venta = ventaClient.getVentaPorId(nuevoEnvio.getId_venta());
        } catch (Exception e) {
            logger.error("Error al consultar microservicio de ventas: {}", e.getMessage());
            throw new RuntimeException("No se pudo consultar el microservicio de ventas.");
        }

        //verificar estado de la venta
        if (!venta.isEstado()) {
            logger.warn("Venta {} no completada. Estado recibido: false", nuevoEnvio.getId_venta());
            throw new IllegalStateException("No se puede crear el envío: La venta no se ha concretado.");
        }

        nuevoEnvio.setEstado("En curso");
        
        Envio guardado = envioRepository.save(nuevoEnvio);
        logger.info("Envío creado exitosamente con id: {}", guardado.getId_envio());
        
        return guardado;
    }

    public void deleteById(int id) {
        logger.info("Eliminando envio con id: {}", id);
        envioRepository.deleteById(id);
        logger.info("Envio con id {} eliminado", id);
    }
}