/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.envio.Service;
import com.tienda.envio.Modelo.Envio;
import com.tienda.envio.dto.VentaResponseDTO;
import com.tienda.envio.Client.VentaClient;
import com.tienda.envio.Repository.FakeRepository;
import com.tienda.envio.dto.EnvioResponseDTO;
import com.tienda.envio.dto.VentaResponseDTO;
import java.util.List;

/**
 *
 * @author Arlettee
 *
 * NOTA: esta clase se usa solo en pruebas unitarias (se instancia
 * manualmente con "new" junto a FakeRepository). NO lleva @Service
 * a propósito: si la tuviera, Spring intentaría crearla como bean real
 * al levantar la aplicación y fallaría porque FakeRepository no es
 * un bean de Spring.
 */
public class EnvioServicePruebas {
    private final FakeRepository repository;
    private final VentaClient ventaClient;

    public EnvioServicePruebas(FakeRepository repository, VentaClient ventaClient) {
        this.repository = repository;
        this.ventaClient=ventaClient;
    }
    //GET{ID}
    public Envio findById(int id){
        return repository.findById(id)
                .orElseThrow(()-> new RuntimeException("Envio no encontrado"));
    }
    //GET
    public List<Envio> findAll(){
        List<Envio> envios = repository.findAll();
        
        //verificar si la lista viene vacía
        if (envios.isEmpty()) {
            throw new IllegalStateException("No existe ningun carrito registrado");
        }
    return repository.findAll();}
    
    //POST
    public EnvioResponseDTO save(Envio nuevoEnvio){
        
        VentaResponseDTO venta;
        //consultar venta
        try {
            venta = ventaClient.getVentaPorId(nuevoEnvio.getId_venta());
        } catch (Exception e) {
            throw new RuntimeException("No se pudo consultar el microservicio de ventas.");
        }

        //verificar estado de la venta
        if (!venta.isEstado()) {
            throw new IllegalStateException("No se puede crear el envío: La venta no se ha concretado.");
        }

        nuevoEnvio.setEstado("En curso");
        
        Envio guardado = repository.save(nuevoEnvio);
        
        return convertirAResponseDTO(guardado);
    }
    public EnvioResponseDTO convertirAResponseDTO(Envio envio) {
        EnvioResponseDTO response = new EnvioResponseDTO();
        response.setId_envio(envio.getId_envio()); 
        response.setEstado(envio.getEstado());
        return response;
    }
    
    //DELETE
    public EnvioResponseDTO deleteById(int id){
    //Se reutiliza el método findById
    //Si el id no existe "findById" lanzará la excepción y detendrá el proceso
    //Si existe se elimina
    Envio envioExistente = this.findById(id);
    repository.deleteById(envioExistente.getId_envio());
    return convertirAResponseDTO(envioExistente);
    }
}

