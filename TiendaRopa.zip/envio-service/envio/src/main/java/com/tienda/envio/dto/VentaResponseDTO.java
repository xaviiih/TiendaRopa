/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.envio.dto;

import java.time.LocalDate;

/**
 *
 * @author Arlettee
 */
public class VentaResponseDTO {
    private int id_venta;
    private boolean estado;

    public VentaResponseDTO(int id_venta, boolean estado) {
        this.id_venta = id_venta;
        this.estado = estado;
    }

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    

    

    }

    
    
    

