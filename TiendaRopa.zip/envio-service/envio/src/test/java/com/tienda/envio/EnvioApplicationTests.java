package com.tienda.envio;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexión a Oracle. La lógica de negocio se prueba en CarritoTest con FakeRepository.")
class CarritoApplicationTests {

    @Test
    void contextLoads() {
    }

}