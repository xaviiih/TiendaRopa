package com.tienda.pago.Repository;

import com.tienda.pago.Modelo.Pago;
import java.util.*;

public class FakePagoRepository {
    private final Map<Integer, Pago> datos = new HashMap<>();

    public FakePagoRepository() {
        datos.put(1, new Pago(1, "Tarjeta de credito", 1, 10));
        datos.put(2, new Pago(2, "Transferencia", 2, 11));
        datos.put(3, new Pago(3, "Webpay", 3, 12));
    }

    public Optional<Pago> findById(int id) { return Optional.ofNullable(datos.get(id)); }
    public List<Pago> findAll() { return new ArrayList<>(datos.values()); }
    public Pago save(Pago pago) { datos.put(pago.getId_pago(), pago); return pago; }
    public void deleteById(int id) { datos.remove(id); }
}
