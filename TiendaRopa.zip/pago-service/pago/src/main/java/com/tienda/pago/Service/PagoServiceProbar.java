package com.tienda.pago.Service;

import com.tienda.pago.Modelo.Pago;
import com.tienda.pago.Repository.FakePagoRepository;
import java.util.List;

public class PagoServiceProbar {
    private final FakePagoRepository repo;

    public PagoServiceProbar(FakePagoRepository repo) { this.repo = repo; }

    public List<Pago> getTodas() { return repo.findAll(); }

    public Pago findById(int id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    public Pago guardar(Pago pago) {
        if (pago.getMetodo_pago() == null || pago.getMetodo_pago().isBlank()) {
            throw new IllegalArgumentException("El metodo de pago es obligatorio");
        }
        return repo.save(pago);
    }

    public void eliminar(int id) { repo.deleteById(id); }
}
