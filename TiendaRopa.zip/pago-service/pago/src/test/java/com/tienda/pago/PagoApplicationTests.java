package com.tienda.pago;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexion a Oracle. La logica de negocio se prueba en PagoTest con un repositorio falso.")
class PagoApplicationTests {

    @Test
    void contextLoads() {
    }

}
