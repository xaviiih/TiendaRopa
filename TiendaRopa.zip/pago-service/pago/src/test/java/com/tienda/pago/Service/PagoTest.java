package com.tienda.pago.Service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.pago.Repository.FakePagoRepository;
import com.tienda.pago.Modelo.Pago;

public class PagoTest {

    @Test
    void debeRetornarPagoCuandoExiste() {
        PagoServiceProbar service = new PagoServiceProbar(new FakePagoRepository());
        Pago pago = service.findById(1);
        assertNotNull(pago);
        assertEquals("Tarjeta de credito", pago.getMetodo_pago());
    }

    @Test
    void debeLanzarErrorCuandoPagoNoExiste() {
        PagoServiceProbar service = new PagoServiceProbar(new FakePagoRepository());
        assertThrows(RuntimeException.class, () -> service.findById(99));
    }

    @Test
    void debeListarLosTresPagosPrecargados() {
        PagoServiceProbar service = new PagoServiceProbar(new FakePagoRepository());
        assertEquals(3, service.getTodas().size());
    }

    @Test
    void debeRechazarPagoSinMetodo() {
        PagoServiceProbar service = new PagoServiceProbar(new FakePagoRepository());
        Pago invalido = new Pago(4, "", 1, 20);
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalido));
    }
}
