package com.tienda.proveedorservice.repository;

import com.tienda.proveedorservice.model.Proveedor;
import java.util.*;

public class FakeProveedorRepository {
    private final Map<Long, Proveedor> datos = new HashMap<>();

    public FakeProveedorRepository() {
        datos.put(1L, crear(1L, "Juan Perez", "Textiles del Sur"));
        datos.put(2L, crear(2L, "Maria Lopez", "Confecciones Andes"));
        datos.put(3L, crear(3L, "Pedro Ramirez", "Importadora Pacifico"));
    }

    private Proveedor crear(Long id, String nombre, String empresa) {
        Proveedor p = new Proveedor();
        p.setId(id); p.setNombre(nombre); p.setEmpresa(empresa);
        return p;
    }

    public Optional<Proveedor> findById(Long id) { return Optional.ofNullable(datos.get(id)); }
    public List<Proveedor> findAll() { return new ArrayList<>(datos.values()); }
    public Proveedor save(Proveedor p) { datos.put(p.getId(), p); return p; }
    public void deleteById(Long id) { datos.remove(id); }
}
