package com.tienda.proveedorservice.service;

import com.tienda.proveedorservice.model.Proveedor;
import com.tienda.proveedorservice.repository.FakeProveedorRepository;
import java.util.List;

public class ProveedorServiceProbar {
    private final FakeProveedorRepository repo;

    public ProveedorServiceProbar(FakeProveedorRepository repo) { this.repo = repo; }

    public List<Proveedor> listar() { return repo.findAll(); }

    public Proveedor guardar(Proveedor proveedor) {
        if (proveedor.getEmpresa() == null || proveedor.getEmpresa().isBlank()) {
            throw new IllegalArgumentException("La empresa no puede estar vacia");
        }
        return repo.save(proveedor);
    }

    public Proveedor obtener(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
