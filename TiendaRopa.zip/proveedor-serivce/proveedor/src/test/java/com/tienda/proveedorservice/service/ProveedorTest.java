package com.tienda.proveedorservice.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.proveedorservice.repository.FakeProveedorRepository;
import com.tienda.proveedorservice.model.Proveedor;

public class ProveedorTest {

    @Test
    void debeRetornarProveedorCuandoExiste() {
        ProveedorServiceProbar service = new ProveedorServiceProbar(new FakeProveedorRepository());
        Proveedor proveedor = service.obtener(1L);
        assertNotNull(proveedor);
        assertEquals("Textiles del Sur", proveedor.getEmpresa());
    }

    @Test
    void debeRetornarNullCuandoProveedorNoExiste() {
        ProveedorServiceProbar service = new ProveedorServiceProbar(new FakeProveedorRepository());
        assertNull(service.obtener(99L));
    }

    @Test
    void debeListarLosTresProveedoresPrecargados() {
        ProveedorServiceProbar service = new ProveedorServiceProbar(new FakeProveedorRepository());
        assertEquals(3, service.listar().size());
    }

    @Test
    void debeRechazarProveedorSinEmpresa() {
        ProveedorServiceProbar service = new ProveedorServiceProbar(new FakeProveedorRepository());
        Proveedor invalido = new Proveedor();
        invalido.setId(4L);
        invalido.setNombre("Sin Empresa");
        invalido.setEmpresa("");
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalido));
    }
}
