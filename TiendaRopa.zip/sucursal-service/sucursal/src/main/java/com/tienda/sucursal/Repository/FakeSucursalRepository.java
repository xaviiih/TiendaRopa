package com.tienda.sucursal.Repository;

import com.tienda.sucursal.Modelo.Sucursal;
import java.util.*;

public class FakeSucursalRepository {
    private final Map<Integer, Sucursal> datos = new HashMap<>();

    public FakeSucursalRepository() {
        datos.put(1, new Sucursal(1, "Providencia"));
        datos.put(2, new Sucursal(2, "Las Condes"));
        datos.put(3, new Sucursal(3, "Nunoa"));
    }

    public Optional<Sucursal> findById(int id) { return Optional.ofNullable(datos.get(id)); }
    public List<Sucursal> findAll() { return new ArrayList<>(datos.values()); }
    public Sucursal save(Sucursal s) { datos.put(s.getId_sucursal(), s); return s; }
    public void deleteById(int id) { datos.remove(id); }
}
