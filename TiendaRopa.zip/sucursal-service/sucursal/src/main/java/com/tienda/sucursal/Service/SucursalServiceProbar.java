package com.tienda.sucursal.Service;

import com.tienda.sucursal.Modelo.Sucursal;
import com.tienda.sucursal.Repository.FakeSucursalRepository;
import java.util.List;

public class SucursalServiceProbar {
    private final FakeSucursalRepository repo;

    public SucursalServiceProbar(FakeSucursalRepository repo) { this.repo = repo; }

    public List<Sucursal> getTodas() { return repo.findAll(); }

    public Sucursal findById(int id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Sucursal no encontrada"));
    }

    public Sucursal guardar(Sucursal sucursal) {
        if (sucursal.getComuna() == null || sucursal.getComuna().isBlank()) {
            throw new IllegalArgumentException("La comuna es obligatoria");
        }
        return repo.save(sucursal);
    }

    public void eliminar(int id) { repo.deleteById(id); }
}
