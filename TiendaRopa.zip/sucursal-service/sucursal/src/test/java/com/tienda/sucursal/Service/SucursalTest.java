package com.tienda.sucursal.Service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.sucursal.Repository.FakeSucursalRepository;
import com.tienda.sucursal.Modelo.Sucursal;

public class SucursalTest {

    @Test
    void debeRetornarSucursalCuandoExiste() {
        SucursalServiceProbar service = new SucursalServiceProbar(new FakeSucursalRepository());
        Sucursal sucursal = service.findById(1);
        assertNotNull(sucursal);
        assertEquals("Providencia", sucursal.getComuna());
    }

    @Test
    void debeLanzarErrorCuandoSucursalNoExiste() {
        SucursalServiceProbar service = new SucursalServiceProbar(new FakeSucursalRepository());
        assertThrows(RuntimeException.class, () -> service.findById(99));
    }

    @Test
    void debeListarLasTresSucursalesPrecargadas() {
        SucursalServiceProbar service = new SucursalServiceProbar(new FakeSucursalRepository());
        assertEquals(3, service.getTodas().size());
    }

    @Test
    void debeRechazarSucursalSinComuna() {
        SucursalServiceProbar service = new SucursalServiceProbar(new FakeSucursalRepository());
        Sucursal invalida = new Sucursal(4, "");
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalida));
    }
}
