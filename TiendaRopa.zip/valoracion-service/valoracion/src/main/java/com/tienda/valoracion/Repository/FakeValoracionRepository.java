package com.tienda.valoracion.Repository;

import com.tienda.valoracion.Modelo.Valoracion;
import java.time.LocalDate;
import java.util.*;

public class FakeValoracionRepository {
    private final Map<Integer, Valoracion> datos = new HashMap<>();

    public FakeValoracionRepository() {
        datos.put(1, new Valoracion(1, 1, 1, 5, LocalDate.now()));
        datos.put(2, new Valoracion(2, 2, 2, 4, LocalDate.now()));
        datos.put(3, new Valoracion(3, 1, 3, 3, LocalDate.now()));
    }

    public Optional<Valoracion> findById(int id) { return Optional.ofNullable(datos.get(id)); }
    public List<Valoracion> findAll() { return new ArrayList<>(datos.values()); }
    public Valoracion save(Valoracion v) { datos.put(v.getId_valoracion(), v); return v; }
    public void deleteById(int id) { datos.remove(id); }
}
