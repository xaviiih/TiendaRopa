package com.tienda.valoracion.Service;

import com.tienda.valoracion.Modelo.Valoracion;
import com.tienda.valoracion.Repository.FakeValoracionRepository;
import java.util.List;

public class ValoracionServiceProbar {
    private final FakeValoracionRepository repo;

    public ValoracionServiceProbar(FakeValoracionRepository repo) { this.repo = repo; }

    public List<Valoracion> getTodas() { return repo.findAll(); }

    public Valoracion findById(int id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Valoracion no encontrada"));
    }

    public Valoracion guardar(Valoracion valoracion) {
        if (valoracion.getEstrellas() < 1 || valoracion.getEstrellas() > 5) {
            throw new IllegalArgumentException("Las estrellas deben estar entre 1 y 5");
        }
        return repo.save(valoracion);
    }

    public void eliminar(int id) { repo.deleteById(id); }
}
