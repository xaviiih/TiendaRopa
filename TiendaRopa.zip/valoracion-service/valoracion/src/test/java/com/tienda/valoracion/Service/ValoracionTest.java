package com.tienda.valoracion.Service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.valoracion.Repository.FakeValoracionRepository;
import com.tienda.valoracion.Modelo.Valoracion;
import java.time.LocalDate;

public class ValoracionTest {

    @Test
    void debeRetornarValoracionCuandoExiste() {
        ValoracionServiceProbar service = new ValoracionServiceProbar(new FakeValoracionRepository());
        Valoracion valoracion = service.findById(1);
        assertNotNull(valoracion);
        assertEquals(5, valoracion.getEstrellas());
    }

    @Test
    void debeLanzarErrorCuandoValoracionNoExiste() {
        ValoracionServiceProbar service = new ValoracionServiceProbar(new FakeValoracionRepository());
        assertThrows(RuntimeException.class, () -> service.findById(99));
    }

    @Test
    void debeListarLasTresValoracionesPrecargadas() {
        ValoracionServiceProbar service = new ValoracionServiceProbar(new FakeValoracionRepository());
        assertEquals(3, service.getTodas().size());
    }

    @Test
    void debeRechazarEstrellasFueraDeRango() {
        ValoracionServiceProbar service = new ValoracionServiceProbar(new FakeValoracionRepository());
        Valoracion invalida = new Valoracion(4, 1, 1, 7, LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalida));
    }
}
