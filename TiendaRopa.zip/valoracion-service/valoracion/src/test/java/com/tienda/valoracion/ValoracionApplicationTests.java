package com.tienda.valoracion;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexion a Oracle. La logica de negocio se prueba en ValoracionTest con un repositorio falso.")
class ValoracionApplicationTests {

    @Test
    void contextLoads() {
    }

}
