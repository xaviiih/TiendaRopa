package com.tienda.vendedorservice.repository;

import com.tienda.vendedorservice.model.Vendedor;
import java.util.*;

public class FakeVendedorRepository {
    private final Map<Long, Vendedor> datos = new HashMap<>();

    public FakeVendedorRepository() {
        datos.put(1L, crear(1L, "Diego Fuentes", "+56911111111"));
        datos.put(2L, crear(2L, "Elena Vidal", "+56922222222"));
        datos.put(3L, crear(3L, "Felipe Rojas", "+56933333333"));
    }

    private Vendedor crear(Long id, String nombre, String telefono) {
        Vendedor v = new Vendedor();
        v.setId(id); v.setNombre(nombre); v.setTelefono(telefono);
        return v;
    }

    public Optional<Vendedor> findById(Long id) { return Optional.ofNullable(datos.get(id)); }
    public List<Vendedor> findAll() { return new ArrayList<>(datos.values()); }
    public Vendedor save(Vendedor v) { datos.put(v.getId(), v); return v; }
    public void deleteById(Long id) { datos.remove(id); }
}
