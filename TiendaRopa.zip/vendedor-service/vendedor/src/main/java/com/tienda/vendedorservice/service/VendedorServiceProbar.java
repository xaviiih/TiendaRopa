package com.tienda.vendedorservice.service;

import com.tienda.vendedorservice.model.Vendedor;
import com.tienda.vendedorservice.repository.FakeVendedorRepository;
import java.util.List;

public class VendedorServiceProbar {
    private final FakeVendedorRepository repo;

    public VendedorServiceProbar(FakeVendedorRepository repo) { this.repo = repo; }

    public List<Vendedor> listar() { return repo.findAll(); }

    public Vendedor guardar(Vendedor vendedor) {
        if (vendedor.getTelefono() == null || vendedor.getTelefono().isBlank()) {
            throw new IllegalArgumentException("El telefono no puede estar vacio");
        }
        return repo.save(vendedor);
    }

    public Vendedor obtener(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
