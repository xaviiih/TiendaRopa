package com.tienda.vendedorservice.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import com.tienda.vendedorservice.repository.FakeVendedorRepository;
import com.tienda.vendedorservice.model.Vendedor;

public class VendedorTest {

    @Test
    void debeRetornarVendedorCuandoExiste() {
        VendedorServiceProbar service = new VendedorServiceProbar(new FakeVendedorRepository());
        Vendedor vendedor = service.obtener(1L);
        assertNotNull(vendedor);
        assertEquals("Diego Fuentes", vendedor.getNombre());
    }

    @Test
    void debeRetornarNullCuandoVendedorNoExiste() {
        VendedorServiceProbar service = new VendedorServiceProbar(new FakeVendedorRepository());
        assertNull(service.obtener(99L));
    }

    @Test
    void debeListarLosTresVendedoresPrecargados() {
        VendedorServiceProbar service = new VendedorServiceProbar(new FakeVendedorRepository());
        assertEquals(3, service.listar().size());
    }

    @Test
    void debeRechazarVendedorSinTelefono() {
        VendedorServiceProbar service = new VendedorServiceProbar(new FakeVendedorRepository());
        Vendedor invalido = new Vendedor();
        invalido.setId(4L);
        invalido.setNombre("Sin Telefono");
        invalido.setTelefono("");
        assertThrows(IllegalArgumentException.class, () -> service.guardar(invalido));
    }
}
