/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.ventaservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.tienda.ventaservice.dto.CarritoResponseDTO;


@FeignClient(name = "carrito-service")
public interface CarritoClient {

    // Este es el método que usaste en tu VentaService: "carritoClient.obtener()"
    @GetMapping("/API/V1/carritos/{id}")
    CarritoResponseDTO obtener(@PathVariable("id") Long id);
    
    
    

}
