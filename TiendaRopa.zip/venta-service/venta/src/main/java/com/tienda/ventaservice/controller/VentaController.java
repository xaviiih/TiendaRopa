package com.tienda.ventaservice.controller;

import com.tienda.ventaservice.dto.VentaRequestDTO;
import com.tienda.ventaservice.model.Venta;
import com.tienda.ventaservice.service.VentaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/API/V1/ventas")
public class VentaController {

    private final VentaService service;

    public VentaController(VentaService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Venta>> getTodas() {
        return ResponseEntity.ok(service.listar());
    }

    @PostMapping
    public ResponseEntity<Venta> guardar(@Valid @RequestBody VentaRequestDTO ventaRequest) {
        Venta creada = service.crearVenta(ventaRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findById(@PathVariable Long id) {
        Venta venta = service.obtener(id);
        if (venta == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("venta no encontrada");
        }
        return ResponseEntity.ok(venta);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        Venta venta = service.obtener(id);
        if (venta == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("venta no encontrada");
        }
        service.eliminar(id);
        return ResponseEntity.ok("Venta eliminada correctamente");
    }
}
