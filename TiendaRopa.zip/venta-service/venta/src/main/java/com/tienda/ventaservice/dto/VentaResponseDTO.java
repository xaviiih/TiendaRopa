/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.ventaservice.dto;
import jakarta.validation.constraints.*;


/**
 *
 * @author Arlettee
 */
public class VentaResponseDTO {
    @Min(value=1, message="el id no puede ser menor a 1")
    private Long id;
    @NotEmpty
    private boolean estadoVenta;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isEstadoVenta() {
        return estadoVenta;
    }

    public void setEstadoVenta(boolean estadoVenta) {
        this.estadoVenta = estadoVenta;
    }
    
 
}
