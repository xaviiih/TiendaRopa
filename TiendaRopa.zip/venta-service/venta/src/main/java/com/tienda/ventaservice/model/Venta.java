package com.tienda.ventaservice.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import jakarta.persistence.Entity;

@Entity
@Table(name="Venta")
public class Venta {

   @Id
   @Column(nullable=false)
   private Long id;
   @Column(nullable=false)
   private LocalDate fecha;
   @Column(nullable=false)
   private double total;
   @Column(nullable=false)
   private boolean estado;

    public Venta() {
    }

    public Venta(Long id, LocalDate fecha, double total, boolean estado) {
        this.id = id;
        this.fecha = fecha;
        this.total = total;
        this.estado = estado;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    

   public Long getId() {
     return id;
   }
   public void setId(Long id) {
     this.id = id;
   }
   public LocalDate getFecha() {
     return fecha;
   }
   public void setFecha(LocalDate fecha) {
     this.fecha = fecha;
   }
   public double getTotal() {
     return total;
   }
   public void setTotal(double total) {
     this.total = total;
   }
}

